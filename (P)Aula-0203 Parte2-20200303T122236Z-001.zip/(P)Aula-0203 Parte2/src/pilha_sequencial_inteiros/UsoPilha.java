package pilha_sequencial_inteiros;

import java.util.Scanner;

import pilha_sequencial_inteiros.PilhaInt.RetornoInt;

public class UsoPilha {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		PilhaInt pilha = new PilhaInt();
		RetornoInt res = new RetornoInt();

		pilha.init();

		System.out.println("Digite um valor decimal -> ");
		PilhaInt.decimal = teclado.nextInt();

		while (PilhaInt.decimal != 0) {
			pilha.push(PilhaInt.decimal % 2);
		}

		res = pilha.pop();
		if (res.sucesso == true) {
			System.out.println("Valor retirado: " + res.elem);
		}

	}

}
